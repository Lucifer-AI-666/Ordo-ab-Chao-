# Licenza d’Uso Personalissimo (LUP) v1.0

Copyright (c) 2025, Anouar Dib. Tutti i diritti riservati.

Questa licenza concede al solo titolare del repository o al soggetto espressamente autorizzato dal titolare (di seguito “Licenziatario”) un diritto limitato ad usare questo software esclusivamente per uso personale, privato e non commerciale, secondo i termini seguenti.

1) Concessione d’uso
- Uso consentito: il Licenziatario può usare, riprodurre e modificare il software unicamente per fini personali, privati e non commerciali, e solo su dispositivi di sua proprietà o sotto il suo controllo.
- Modifiche: le modifiche sono consentite ma restano soggette a questa stessa licenza. Le opere derivate non possono essere condivise o distribuite.

2) Restrizioni
È espressamente vietato, senza previa autorizzazione scritta del titolare:
- Distribuire, pubblicare, rendere disponibile a terzi, concedere in sublicenza o vendere il software o opere derivate (in forma sorgente o binaria).
- Fornire il software come servizio (SaaS), ospitarlo pubblicamente o utilizzarlo in ambito commerciale, professionale o a scopo di lucro.
- Integrare il software in prodotti o servizi destinati a terzi.
- Utilizzare il software, il codice o i dati correlati per addestrare modelli di intelligenza artificiale o sistemi di machine learning, né effettuare text/data mining a tali fini.
- Rimuovere o alterare avvisi di copyright, note di licenza o attribuzione.

3) Riservatezza
Il software deve essere trattato come contenuto riservato. Se archiviato su servizi di terzi (es. hosting o repo remota), il Licenziatario deve mantenerlo privato e adeguatamente protetto (es. repository privata, controlli di accesso, 2FA).

4) Durata e risoluzione
La licenza è valida fino a revoca. In caso di violazione, la licenza si risolve automaticamente e il Licenziatario deve cessare l’uso e cancellare ogni copia del software e delle opere derivate.

5) Nessuna garanzia
Il software è fornito “COSÌ COM’È”, senza garanzie di alcun tipo, espresse o implicite, incluse, a titolo esemplificativo, le garanzie di commerciabilità, idoneità per un particolare scopo e non violazione di diritti altrui.

6) Limitazione di responsabilità
In nessun caso l’Autore o i Contribuenti saranno responsabili per danni diretti, indiretti, incidentali, speciali, esemplari o consequenziali derivanti dall’uso o dall’impossibilità di usare il software.

7) Legge applicabile
Salvo diversa disposizione di legge inderogabile, la presente licenza è disciplinata dalla legge del paese di residenza del titolare dei diritti.

Per usi diversi da quelli consentiti (es. commerciali, distribuzione, integrazione in prodotti/servizi, ricerca/AI), contattare il titolare per ottenere una licenza separata.