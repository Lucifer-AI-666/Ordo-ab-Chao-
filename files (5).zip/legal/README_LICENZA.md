# Sintesi licenza (LUP v1.0)

Titolare: Anouar Dib

- Consentito:
  - Uso personale, privato e non commerciale.
  - Modifiche locali per proprio uso (non condivisibili).

- Vietato senza permesso scritto:
  - Distribuzione, pubblicazione, sublicenza, vendita.
  - Uso commerciale/professionale, hosting pubblico, SaaS.
  - Integrazione in prodotti/servizi per terzi.
  - Addestramento AI / text & data mining.
  - Rimozione di note di copyright/licenza.

- Riservatezza: mantieni il codice in repository privata e protetta (accessi limitati, 2FA).
- Violazioni: comportano revoca automatica della licenza e obbligo di cancellazione delle copie.
- Garanzia/Responsabilità: nessuna garanzia; responsabilità esclusa nei limiti di legge.

Nota: questa licenza NON è open source. Per usi extra (es. commerciali), contatta il titolare per una licenza separata.